package com.geektext.app.Group7_RESTful.API.controller;

import com.geektext.app.Group7_RESTful.API.models.Book;
import com.geektext.app.Group7_RESTful.API.repo.BookRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ApiControllers {

    @Autowired
    private BookRepo bookRepo;

    @GetMapping(value = "/")
    public String getPage(){
        return "Welcome";
    }

    @GetMapping(value = "/books")
    public List<Book> getBooks(){
        return bookRepo.findAll();
    }

    @PostMapping(value = "/save")
    public String saveBook(@RequestBody Book book){
        bookRepo.save(book);
        return "Saved book...";
    }

    @PutMapping(value = "update/{id}")
    public String updateBook(@PathVariable long id, @RequestBody Book book){
        Book updatedBook = bookRepo.findById(id).get();
        updatedBook.setBookName(book.getBookName());
        updatedBook.setBookAuthor(book.getBookAuthor());
        updatedBook.setBookPrice(book.getBookPrice());
        bookRepo.save(updatedBook);
        return "Updated Book...";
    }

    @DeleteMapping(value = "/delete/{id}")
    public String deleteBook(@PathVariable long id){
        Book deleteBook = bookRepo.findById(id).get();
        bookRepo.delete(deleteBook);
        return "Delete book with the id: " + id;
    }
}
