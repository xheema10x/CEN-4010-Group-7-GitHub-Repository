package com.geektext.app.Group7_RESTful.API.repo;

public interface OrderRepo {
}
