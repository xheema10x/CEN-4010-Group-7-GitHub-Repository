package com.geektext.app.Group7_RESTful.API.repo;

import com.geektext.app.Group7_RESTful.API.models.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepo extends JpaRepository<Customer, Long> {
}
