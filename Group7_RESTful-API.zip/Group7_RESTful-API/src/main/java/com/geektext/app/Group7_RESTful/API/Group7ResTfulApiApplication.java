package com.geektext.app.Group7_RESTful.API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Group7ResTfulApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Group7ResTfulApiApplication.class, args);
	}

}
