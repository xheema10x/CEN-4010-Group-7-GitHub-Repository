package com.geektext.app.Group7_RESTful.API.models;

public class ShoppingCart {
}
