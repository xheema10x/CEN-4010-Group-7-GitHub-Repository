package com.geektext.app.Group7_RESTful.API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Group7ResTfulApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
