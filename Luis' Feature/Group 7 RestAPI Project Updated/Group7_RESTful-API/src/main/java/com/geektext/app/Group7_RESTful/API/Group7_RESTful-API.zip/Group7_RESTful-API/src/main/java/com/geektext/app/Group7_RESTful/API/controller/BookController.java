package com.geektext.app.Group7_RESTful.API.controller;

import com.geektext.app.Group7_RESTful.API.models.Book;
import com.geektext.app.Group7_RESTful.API.models.User;
import com.geektext.app.Group7_RESTful.API.repo.BookRepo;
import com.geektext.app.Group7_RESTful.API.repo.UserRepo;
import com.geektext.app.Group7_RESTful.API.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class BookController {

    @Autowired
    BookRepo bookRepo;

    @Autowired
    UserRepo userRepo;

    @Autowired
    BookService bookService;

    @GetMapping(value = "/")
    public String getPage(){
        return "Welcome to our Group 7 Team Project!";
    }

    @GetMapping(value = "/books")
    public List<Book> getBooks(){
        return bookRepo.findAll();
    }


    @PostMapping(value = "/saveBook")
    public void saveBook(@RequestBody Book book){
        bookService.addBook(book);
    }


    @PutMapping(value = "update/{id}")
    public String updateBook(@PathVariable long id, @RequestBody Book book){
        return bookService.updateBook(id, book);
    }

    @DeleteMapping(value = "/delete/{id}")
    public String deleteBook(@PathVariable long id){
        return bookService.deleteBook(id);
    }

    /*@PutMapping(value = "books/{bookId}/user/{userId}")
    Book addBookToCart(@PathVariable Long bookId, @PathVariable Long userId){
        Book book = bookRepo.findById(bookId).get();
        User user = userRepo.findById(userId).get();
        book.assignShoppingCartToUser(user);
        userRepo.save(user);
        return bookRepo.save(book);
    }
     */
    @PutMapping(value = "/book/{bookId}/user/{userId}")
    Book addBookToUserCart(@PathVariable Long bookId, @PathVariable Long userId){
        Book book = bookRepo.getReferenceById(bookId);
        User user = userRepo.getReferenceById(userId);
        book.assignShoppingCartToUser(user);
        user.addBooktoCart(book);
        userRepo.save(user);
        return bookRepo.save(book);
    }
}
