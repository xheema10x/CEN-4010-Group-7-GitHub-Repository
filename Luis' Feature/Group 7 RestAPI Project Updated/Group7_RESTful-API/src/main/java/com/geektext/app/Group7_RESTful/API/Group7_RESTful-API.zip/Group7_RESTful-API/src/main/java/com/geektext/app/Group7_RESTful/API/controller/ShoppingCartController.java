package com.geektext.app.Group7_RESTful.API.controller;

import com.geektext.app.Group7_RESTful.API.models.Book;
import com.geektext.app.Group7_RESTful.API.models.User;
import com.geektext.app.Group7_RESTful.API.repo.BookRepo;
import com.geektext.app.Group7_RESTful.API.repo.UserRepo;
import com.geektext.app.Group7_RESTful.API.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

public class ShoppingCartController {

    @Autowired
    BookRepo bookRepo;

    @Autowired
    UserRepo userRepo;

    @Autowired
    BookService bookService;


    @PutMapping(value = "/book/{bookId}/user/{userId}")
    Book addBookToUserCart(@PathVariable Long bookId, @PathVariable Long userId){
        Book book = bookRepo.getReferenceById(bookId);
        User user = userRepo.getReferenceById(userId);
        book.assignShoppingCartToUser(user);
        user.addBooktoCart(book);
        userRepo.save(user);
        return bookRepo.save(book);
    }
}
